import os
from contextlib import asynccontextmanager

import gradio as gr
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from supabase import create_client, Client

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError("SUPABASE_URL and SUPABASE_KEY must be set in environment variables.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


class StudentCreate(BaseModel):
    name: str
    course: str
    marks: int


class StudentUpdate(BaseModel):
    marks: int


app = FastAPI(title="Student Management System API")


@app.get("/")
def root():
    return {"message": "Student Management System is running", "ui": "/gradio", "docs": "/docs"}


@app.post("/students")
def create_student(student: StudentCreate):
    if not student.name.strip() or not student.course.strip():
        raise HTTPException(status_code=400, detail="Name and course are required.")
    if not 0 <= student.marks <= 100:
        raise HTTPException(status_code=400, detail="Marks must be between 0 and 100.")

    response = (
        supabase.table("students")
        .insert({
            "name": student.name.strip(),
            "course": student.course.strip(),
            "marks": student.marks,
        })
        .execute()
    )
    return {"message": "Student created successfully", "data": response.data}


@app.get("/students")
def get_students():
    response = (
        supabase.table("students")
        .select("*")
        .order("id", desc=False)
        .execute()
    )
    return {"message": "Students fetched successfully", "data": response.data}


@app.get("/students/{student_id}")
def get_student(student_id: int):
    response = (
        supabase.table("students")
        .select("*")
        .eq("id", student_id)
        .execute()
    )
    if not response.data:
        raise HTTPException(status_code=404, detail="Student not found.")
    return {"message": "Student fetched successfully", "data": response.data[0]}


@app.put("/students/{student_id}")
def update_student(student_id: int, student: StudentUpdate):
    if not 0 <= student.marks <= 100:
        raise HTTPException(status_code=400, detail="Marks must be between 0 and 100.")

    response = (
        supabase.table("students")
        .update({"marks": student.marks})
        .eq("id", student_id)
        .execute()
    )
    if not response.data:
        raise HTTPException(status_code=404, detail="Student not found.")
    return {"message": "Student updated successfully", "data": response.data}


@app.delete("/students/{student_id}")
def delete_student(student_id: int):
    response = (
        supabase.table("students")
        .delete()
        .eq("id", student_id)
        .execute()
    )
    if not response.data:
        raise HTTPException(status_code=404, detail="Student not found.")
    return {"message": "Student deleted successfully", "data": response.data}


# -------------------------
# Gradio UI
# -------------------------

def load_students():
    result = get_students()
    rows = result["data"]
    return [[r.get("id"), r.get("name"), r.get("course"), r.get("marks")] for r in rows]


def add_student_ui(name, course, marks):
    try:
        result = create_student(StudentCreate(name=name or "", course=course or "", marks=int(marks)))
        return f"✅ {result['message']}", load_students()
    except Exception as e:
        return f"❌ Error: {str(e)}", load_students()


def update_student_ui(student_id, marks):
    try:
        result = update_student(int(student_id), StudentUpdate(marks=int(marks)))
        return f"✅ {result['message']}", load_students()
    except Exception as e:
        return f"❌ Error: {str(e)}", load_students()


def delete_student_ui(student_id):
    try:
        result = delete_student(int(student_id))
        return f"✅ {result['message']}", load_students()
    except Exception as e:
        return f"❌ Error: {str(e)}", load_students()


with gr.Blocks(title="Student Management System") as demo:
    gr.Markdown(
        """
        # 🎓 Student Management System
        Simple CRUD application using **FastAPI + Gradio + Supabase**
        """
    )

    with gr.Tab("Create Student"):
        name = gr.Textbox(label="Student Name", placeholder="Enter student name")
        course = gr.Textbox(label="Course", placeholder="e.g. Computer Science")
        marks = gr.Number(label="Marks (0-100)", precision=0)
        add_btn = gr.Button("Add Student", variant="primary")
        add_status = gr.Markdown()
        add_table = gr.Dataframe(
            headers=["ID", "Name", "Course", "Marks"],
            datatype=["number", "str", "str", "number"],
            interactive=False,
            label="Students"
        )
        add_btn.click(add_student_ui, [name, course, marks], [add_status, add_table])

    with gr.Tab("View Students"):
        refresh_btn = gr.Button("🔄 Refresh")
        student_table = gr.Dataframe(
            headers=["ID", "Name", "Course", "Marks"],
            datatype=["number", "str", "str", "number"],
            interactive=False,
        )
        refresh_btn.click(load_students, outputs=student_table)

    with gr.Tab("Update Marks"):
        update_id = gr.Number(label="Student ID", precision=0)
        update_marks = gr.Number(label="New Marks (0-100)", precision=0)
        update_btn = gr.Button("Update Marks", variant="primary")
        update_status = gr.Markdown()
        update_table = gr.Dataframe(
            headers=["ID", "Name", "Course", "Marks"],
            datatype=["number", "str", "str", "number"],
            interactive=False,
        )
        update_btn.click(update_student_ui, [update_id, update_marks], [update_status, update_table])

    with gr.Tab("Delete Student"):
        delete_id = gr.Number(label="Student ID", precision=0)
        delete_btn = gr.Button("Delete Student", variant="stop")
        delete_status = gr.Markdown()
        delete_table = gr.Dataframe(
            headers=["ID", "Name", "Course", "Marks"],
            datatype=["number", "str", "str", "number"],
            interactive=False,
        )
        delete_btn.click(delete_student_ui, [delete_id], [delete_status, delete_table])


app = gr.mount_gradio_app(app, demo, path="/gradio")
