# Student Management System — FastAPI + Gradio + Supabase

A beginner-friendly Student Management System with simple CRUD operations.

## Features

- Create student
- View all students
- Update student marks
- Delete student
- REST API with FastAPI
- Gradio web interface
- Supabase PostgreSQL database
- Ready for Render deployment

## 1. Create the Supabase database

Open your Supabase project.

Go to:

**SQL Editor → New query**

Copy and run everything from `supabase.sql`.

Your table will be:

| Column | Type |
|---|---|
| id | bigint, primary key, identity |
| name | varchar(100) |
| course | varchar(100) |
| marks | integer |

## 2. Get Supabase credentials

In your Supabase project, open the API/settings area and copy:

- Project URL
- Server-side API key

Put them in a local `.env` file:

```env
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_KEY=your-server-side-key
```

Never commit `.env` to GitHub.

## 3. Run locally

Open a terminal in this project folder:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Install packages:

```bash
pip install -r requirements.txt
```

Run:

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000/gradio
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

## 4. Test CRUD

### Create
Use the Gradio "Create Student" tab or:

`POST /students`

### Read all
`GET /students`

### Read one
`GET /students/{student_id}`

### Update marks
`PUT /students/{student_id}`

### Delete
`DELETE /students/{student_id}`

## 5. Upload to GitHub

Create a new GitHub repository.

Do NOT upload `.env`.

Upload these files:

- `main.py`
- `requirements.txt`
- `supabase.sql`
- `render.yaml`
- `.gitignore`
- `.env.example`
- `README.md`

## 6. Deploy on Render

Create a new **Web Service** on Render and connect your GitHub repository.

Build command:

```text
pip install -r requirements.txt
```

Start command:

```text
uvicorn main:app --host 0.0.0.0 --port $PORT
```

Add environment variables:

```text
SUPABASE_URL = your Supabase project URL
SUPABASE_KEY = your server-side Supabase key
```

After deployment, open:

```text
https://YOUR-RENDER-SERVICE.onrender.com/gradio
```

## Important security note

The Supabase server-side key must stay on the backend. Do not place it in Gradio client code, HTML, JavaScript, GitHub, or a public repository.

For a production application with user authentication, use proper Supabase Auth and Row Level Security (RLS).
